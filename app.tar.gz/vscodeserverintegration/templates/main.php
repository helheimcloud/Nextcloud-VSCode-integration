<?php
declare(strict_types=1);
// SPDX-FileCopyrightText: René Rettig <rene.rettig@helheim.cloud>
// SPDX-License-Identifier: AGPL-3.0-or-later
?>
<div id="content"></div>
